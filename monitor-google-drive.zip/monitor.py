import os.path
import pytz
from google.auth.transport.requests import Request
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from google.oauth2.credentials import Credentials
from datetime import datetime

# Scopes required by the script
SCOPES = ['https://www.googleapis.com/auth/drive']

def display_title():
    title = """

   ___                  _              ___      _                                    _ _             
  / _ \___   ___   __ _| | ___        /   \_ __(_)_   _____        /\/\   ___  _ __ (_) |_ ___  _ __ 
 / /_\/ _ \ / _ \ / _` | |/ _ \_____ / /\ / '__| \ \ / / _ \_____ /    \ / _ \| '_ \| | __/ _ \| '__|
/ /_\\ (_) | (_) | (_| | |  __/_____/ /_//| |  | |\ V /  __/_____/ /\/\ \ (_) | | | | | || (_) | |   
\____/\___/ \___/ \__, |_|\___|    /___,' |_|  |_| \_/ \___|     \/    \/\___/|_| |_|_|\__\___/|_|   
                  |___/                                                                              

"""

    print(title)

def is_folder_public(folder_id, service):
    """Check if the specified folder is publicly accessible."""
    try:
        folder = service.files().get(fileId=folder_id, fields='permissions').execute()
        return any(perm.get('type') == 'anyone' for perm in folder.get('permissions', []))
    except HttpError as error:
        print(f'An error occurred: {error}')
        return False

def main():
    display_title()
    creds = None
    if os.path.exists('token.json'):
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file('credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)
        with open('token.json', 'w') as token:
            token.write(creds.to_json())

    script_start_time = datetime.utcnow().replace(tzinfo=pytz.UTC)
    # To keep track of file IDs that have already been processed
    processed_files = set()
            
    try:
        service = build('drive', 'v3', credentials=creds)

        # Get the starting page token for changes
        response = service.changes().getStartPageToken().execute()
        page_token = response.get('startPageToken')

        print("\033[1m\033[92mMonitoring for files being uploaded...\033[0m")

        # Continuously check for new changes
        while True:
            response = service.changes().list(pageToken=page_token, spaces='drive').execute()

            for change in response.get('changes', []):
                file_id = change.get('fileId')
                file = service.files().get(fileId=file_id, fields='id, name, parents, permissions, createdTime, modifiedTime').execute()

                file_created_time = datetime.strptime(file.get('createdTime'), '%Y-%m-%dT%H:%M:%S.%fZ').replace(tzinfo=pytz.UTC)

                if file_id in processed_files:
                    continue

                # Check if the file is newly uploaded
                if file_created_time > script_start_time:  
                    print(f"New file uploaded: {file['name']} (ID: {file['id']})")
                    
                    processed_files.add(file_id)

                    # Output current permissions of the file
                    print("Current permissions:")
                    for perm in file.get('permissions', []):
                        print(f"  - Type: {perm.get('type')}, Role: {perm.get('role')}")

                    # Check each parent folder
                    in_public_folder = any(is_folder_public(parent, service) for parent in file.get('parents', []))

                    if in_public_folder:
                        # Check if the file is publicly accessible
                        if any(perm.get('type') == 'anyone' for perm in file.get('permissions', [])):
                            # Remove public access permissions
                            for perm in file.get('permissions', []):
                                if perm.get('type') == 'anyone':
                                    try:
                                        service.permissions().delete(fileId=file_id, permissionId=perm['id']).execute()
                                        print(f"Updated file '{file['name']}' to private")
                                    except HttpError as error:
                                        print(f'An error occurred while updating permissions: {error}')

            # Update pageToken for the next iteration
            if 'newStartPageToken' in response:
                page_token = response.get('newStartPageToken')
            else:
                page_token = response.get('nextPageToken')
                if not page_token:
                    break

    except HttpError as error:
        print(f'An error occurred: {error}')

if __name__ == '__main__':
    main()
